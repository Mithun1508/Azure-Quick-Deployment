# DEPRECATION NOTICE

The `SqlDatabaseOwner` DSC resource is **DEPRECATED**. The resource is
replaced by a property in the resource `SqlDatabase`.

The documentation, examples, unit test, and integration tests have been
removed. This resource will be removed in a future release.
